# CSX42: Assignment 1
## Name: 
Renze Chen

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in coursesRegistration/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

#### Command: ant -buildfile coursesRegistration/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

#### Command: ant -buildfile coursesRegistration/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

#### Command: ant -buildfile coursesRegistration/src/build.xml run -Darg0="student_coursePrefs.txt" -Darg1="courseInfo.txt" -Darg2="registration_results.txt"

Note: Arguments accept the absolute path of the files.

Please place file under `./renze_chen_assign1/coursesRegistration/`

-----------------------------------------------------------------------
## Description:
The program accepts three files as arguments. It takes `student_coursePrefs.txt` and `courseInfo.txt` as input, and writes the registration results to `registration_results.txt`.

The `student_coursePrefs.txt` should have the following format:
```
<student_id> <PREF_1>,<PREF_2>,<PREF_3>,<PREF_4>,<PREF_5>,<PREF_6>,<PREF_7>,<PREF_8>,<PREF_9>::<student_level>
```

The `courseInfo.txt` should have the following format:
```
<course_name> CAPACITY:<capacity>;CLASS_TIMING:<class_time>
```

Assume the first argument to be `student_coursePrefs.txt`, the second argument 
to be `courseInfo.txt`, the third argument to be `registration_results.txt`.

-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

Renze Chen
Date: [2019/9/18]


