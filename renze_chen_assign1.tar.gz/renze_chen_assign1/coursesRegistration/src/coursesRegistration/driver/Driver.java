package coursesRegistration.driver;

import java.util.List;
import java.util.ArrayList;

import coursesRegistration.scheduler.Scheduler;
import coursesRegistration.util.Results;

/**
 * @author Renze Chen
 *
 */
public class Driver {
	public static void main(String[] args) {
		if (args.length != 3 || args[0].equals("${arg0}") 
			|| args[1].equals("${arg1}") || args[2].equals("${arg2}")) {

			System.err.println("Error: Incorrect number of arguments. Program accepts 3 argumnets.");
			System.exit(0);
		}
		Scheduler sch = new Scheduler(args[0], args[1]);
		sch.registerCourse();
		
		Results res = new Results();
		res.writeResult(args[2], sch.getFinalResult());
	}

	public String toString() {
		return "Driver";
	}
}
