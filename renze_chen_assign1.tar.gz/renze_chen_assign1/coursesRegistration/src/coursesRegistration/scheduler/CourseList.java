package coursesRegistration.scheduler;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.HashSet;
import coursesRegistration.util.FileProcessor;

public class CourseList {
	private int[] capacityList; // 0 for A, 1 for B, ect
	private int[] timingList;

	public CourseList(String fileName) {
		this.capacityList = new int[9];
		this.timingList = new int[9];
		buildCourseList(fileName);
	}

	public int[] getCapList() {
		return this.capacityList;
	}

	public int[] getTimingList() {
		return this.timingList;
	}

	public void setCapacity(char courseName, int cap) {
		int idx = courseName - 'A';
		this.capacityList[idx] = cap;
	}

	public void setTiming(char courseName, int timing) {
		int idx =  courseName - 'A';
		this.timingList[idx] = timing;
	}

	/**
	 * Build course list from file
	 */
	private void buildCourseList(String fileName) {
		FileProcessor fp = new FileProcessor();
		try {
			List<String> lines = fp.readFile(fileName);
			if (lines.size() != 9) {
				throw new Exception("Error: wrong courseInfo.");
			}

			Set<Integer> setCouse = new HashSet<>();  // Check whether there is duplicate course
			for (String line : lines) {
				String[] courseInfo = line.split(";");
				int idx = line.charAt(0) - 'A'; 

				if (!setCouse.add(idx) || idx < 0 || idx > 8) {
					throw new Exception("Error: wrong courseInfo.");
				}

				// Find capacity
				String[] strs = courseInfo[0].split(":");  
				this.capacityList[idx] = Integer.parseInt(strs[1]); 

				// Find timingList
				strs = courseInfo[1].split(":");
				this.timingList[idx] = Integer.parseInt(strs[1]); 
			}
		} catch (NumberFormatException e) {
			System.err.println("Error: number format in file '" + fileName + "' is wrong.");
			System.err.println("Please check README for correct input file format.");
			System.exit(0);
		} catch (Exception e) {
			System.err.println("Error: format or content in file '" + fileName + "' is wrong.");
			System.err.println("Please check README for correct input file format.");
			System.exit(0);
		}
	}

	/**
	 * Update the capacityList for courseName
	 */
	public void update(char courseName) {
		if (!hasRoom(courseName)) {
			System.err.println("Error: Cannot register a course without room.");
			System.exit(0);
		}
		int idx = courseName - 'A';
		this.capacityList[idx]--;
	}

	/**
	 * Check whether the courseName still has room
	 */
	public boolean hasRoom(char courseName) {
		int idx = courseName - 'A';
		return this.capacityList[idx] > 0;
	}

	/**
	 * Check whether the courseName conflicts with courses the student has registered
	 */
	public boolean hasConflict(Student stu, char courseName) {
		boolean res = false;
		int idx = courseName - 'A';
		List<Character> regList = stu.getRegList();
		for (char ch : regList) {
			int tempIdx = ch - 'A';
			if (this.timingList[idx] == this.timingList[tempIdx]) {
				res = true;
				break;
			}
		}
		return res;
	}

	public String toString() {
		return "CourseList";
	}
}