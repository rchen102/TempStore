package coursesRegistration.scheduler;

import java.util.List;
import java.util.ArrayList;
import java.text.DecimalFormat;


public class Scheduler {
	private StudentList stuList;
	private CourseList couList;

	public Scheduler(String stuFile, String courseFile) {
		stuList = new StudentList(stuFile);
		couList = new CourseList(courseFile);
	}

	/**
	 * Register courses for students from input list
	 */	
	private void registerForStuList(List<Student> list) {
		try {		
			for (Student stu : list) {
				int num = 0; // courses regestered
				List<Character> prefList = stu.getPrefList();
				for (char course : prefList) {
					if (num == 3) break;
					if (this.couList.hasRoom(course) && !this.couList.hasConflict(stu, course)) {
						stu.regCourse(course);
						this.couList.update(course);
						num++;
					}
				}
			}
		} catch (Exception e) {
			System.err.println("Error occurred when register course for students.");
			System.err.println("Please check README for correct input file format.");
			System.exit(0);
		}
	}

	/**
	 * Register courses for all students
	 */	
	public void registerCourse() {
		System.out.println("Course registration start.");
		registerForStuList(stuList.getThirdStuList());
		registerForStuList(stuList.getSecondStuList());
		registerForStuList(stuList.getFirstStuList());
		System.out.println("Course registration finish.");
	}

	/**
	 * Format the final results and store in a list
	 */	
	public List<String> getFinalResult() {
		List<String> res = new ArrayList<>();
		int sumSatisfaction = 0;
		for (Student stu : this.stuList.getAllStuList()) {
			int satifaction = stu.getSatisfaction();
			sumSatisfaction += satifaction;
			List<Character> courses = stu.getRegList();

			String line = stu.getId() + ":"; // Construct line to write
			for (char ch : courses) {
				line += String.valueOf(ch) + ",";
			}
			line = line.substring(0, line.length() - 1);
			line += "::SatisfactionRating=" + satifaction + "\n";
			res.add(line);
		}
		double aveSatisfaction = sumSatisfaction / (double)(this.stuList.getAllStuList().size());
		DecimalFormat df = new DecimalFormat("0.00"); // keep 2 decimals
		res.add("AverageSatisfactionRating=" + df.format(aveSatisfaction) + "\n");
		return res;
	}


	public String toString() {
		return "Scheduler";
	}
}