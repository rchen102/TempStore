package coursesRegistration.scheduler;

import java.util.List;
import java.util.ArrayList;

public class Student {
	private int id;                 
	private int level;
	private List<Character> prefList;  // List of courses preferred
	private List<Character> regList;   // List of courses registered


	public Student(int idIn, int levelIn) {
		this.id = idIn;
		this.level = levelIn;
		this.prefList = new ArrayList<Character>();
		this.regList = new ArrayList<Character>();
	}

	public int getId() {
		return this.id;
	}

	public int getLevel() {
		return this.level;
	}

	public List<Character> getPrefList() {
		return this.prefList;
	}

	public List<Character> getRegList() {
		return this.regList;
	}

	public void addPrefCourse(char course) {
		this.prefList.add(course);
	}

	public void regCourse(char course) {
		this.regList.add(course);
	}

	public int getSatisfaction() {
		int res = 0;
		for (char course : regList) {
			for (int i = 0; i < 9; i++) {
				if (prefList.get(i) == course) {
					res += (9 - i);
					break;
				}
			}
		}
		return res;
	}

	public String toString() {
		return ("My id is " + this.id + ", and my level is " + this.level);
	}
}