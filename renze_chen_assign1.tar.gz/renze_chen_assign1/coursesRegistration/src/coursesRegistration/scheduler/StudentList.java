package coursesRegistration.scheduler;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import coursesRegistration.util.FileProcessor;

public class StudentList {
	public List<Student> stuList;      // All student list
	public List<Student> firStuList;   // First-year student list
	public List<Student> secStuList;   // Second-year student list
	public List<Student> thirStuList;  // Third-year student list

	public StudentList(String fileName) {
		this.stuList = new ArrayList<Student>();
		this.firStuList = new ArrayList<Student>();
		this.secStuList = new ArrayList<Student>();
		this.thirStuList = new ArrayList<Student>();
		buildStuList(fileName);
	}

	/**
	 * Build student list from file
	 */
	private void buildStuList(String fileName) {
		// Build student list from file
		FileProcessor fp = new FileProcessor();
		Set<Integer> setId = new HashSet<>();  // Check whether there is duplicate id
		try {
			for (String str : fp.readFile(fileName)) {
				int stuId, stuLevel;

				// Find Id
				String[] stuInfo = str.split(" ");
				stuId = Integer.parseInt(stuInfo[0]);
				
				if (!setId.add(stuId)) throw new Exception("Error: repeated student existed.");

				// Find level
				String[] prefsInfo = stuInfo[1].split("::");
				if (prefsInfo[1].startsWith("F")) stuLevel = 1;
				else if (prefsInfo[1].startsWith("S")) stuLevel = 2;
				else if (prefsInfo[1].startsWith("T")) stuLevel = 3;
				else {
					stuLevel = -1;
					throw new Exception("Error: please declare student level correctly.");
				}

				// Find preferred courses
				Set<Integer> setCouse = new HashSet<>();  // Check whether student choose 9 different courses
				Student aStu = new Student(stuId, stuLevel);
				for (int i = 0; i < prefsInfo[0].length(); i += 2) {
					char course = prefsInfo[0].charAt(i);
					int idx = course - 'A';

					if (!setCouse.add(idx) || idx < 0 || idx > 8) {
						throw new Exception("Error: please check requirements for student preferences.");
					}
					aStu.addPrefCourse(course);
				}

				// Add to student list
				this.stuList.add(aStu);
				if (stuLevel == 1) this.firStuList.add(aStu);
				else if (stuLevel == 2) this.secStuList.add(aStu);
				else this.thirStuList.add(aStu);
			}
		} catch (NumberFormatException e) {
			System.err.println("Error: number format in file '" + fileName + "' is wrong.");
			System.err.println("Please check README for correct input file format.");
			System.exit(0);
		} catch (Exception e) {
			System.err.println("Error: format or content in file '" + fileName + "' is wrong.");
			System.err.println("Please check README for correct input file format.");
			System.exit(0);
		}
	}

	public List<Student> getAllStuList() {
		return this.stuList;
	}

	public List<Student> getFirstStuList() {
		return this.firStuList;
	}

	public List<Student> getSecondStuList() {
		return this.secStuList;
	}

	public List<Student> getThirdStuList() {
		return this.thirStuList;
	}

	public String toString() {
		String line = "First-year: " + this.firStuList.size() 
					+ "; Second-year: " + this.secStuList.size()
					+ "; Third-year: " + this.thirStuList.size();
		return line; 
	}
}