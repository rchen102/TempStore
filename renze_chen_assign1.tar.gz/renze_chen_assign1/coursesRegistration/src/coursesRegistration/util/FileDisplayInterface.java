package coursesRegistration.util;

public interface FileDisplayInterface {
	void showFileContent(String fileName);
}
