package coursesRegistration.util;

public interface StdoutDisplayInterface {
}
