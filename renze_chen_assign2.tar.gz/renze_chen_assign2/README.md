# CSX42: Assignment 2
## Name 
Renze Chen

## Running
Following are the commands and the instructions to run ANT on this project.

1. __Instruction to compile__
   ```shell
   ant -buildfile src/build.xml all
   ```
   Compiles your code and generates `.class` files inside the BUILD folder.

2. __Instruction to run__
   ```shell
   ant -buildfile src/build.xml run -Darg0="input.txt" -Darg1="output.txt"
   ```
   Note: to run successfully, please place files under `/renze_chen_assign2`

3. __Instruction to clean__
   ```shell
   ant -buildfile src/build.xml clean
   ```
   It cleans up all the `.class` files that were generated when you
compiled your code.

## Description
The program accepts two files as arguments. It takes `input.txt` as input, and writes results to `ouput.txt`.

The format of __input__ file should be:

    <studentID>: <course> <course> <course> ... <course>

The format of __output__ file should be:

    <studentID> <course completed> <course completed> ... <course completed> -- <# semesters> <# state changes>

An example of a possible input,output file:
    
    Input: 
    1234: A B C D E F G H I J K L M N O P Q R S T U V W

    Output: 
    1234: A E I B F J C G K D H L M Q R N -- 6 0

## Algorithm

To process a student, the program will do the following steps:

1. Read one line information from the `input.txt` file to initialize student.

2. Add all the courses to a wait list, set student to __group1__.

3. Each semester, the planner will try to process 3 courses for student. If the planner fail to process 3 courses and the student can not graduate from the current semester, stop planner.

4. Each time to process a course, the planner will pop the __first__ course that could be assigned to the student from the wait list, as well as check if the student need to be transfered to other state.

5. After processing one course for student, the planner will check whether the student satisfies the graduate requirments, if yes, stop planner. 

6. If no more course could be assigned to the student, and the student still doesnot satisfy the graduate requirements, stop planner.

7. Write the final result into `output.txt`

## Academic Honesty statement
"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

__Name__: Renze Chen __Date__: [2019/10/5]


