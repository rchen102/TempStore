package coursePlanner.driver;

import coursePlanner.util.FileProcessor;
import coursePlanner.util.Results;
import coursePlanner.state.CoursePlanner;

/**
 * @author Renze Chen
 *
 */
public class Driver {
	public static void main(String[] args) {
		if (args.length != 2 || args[0].equals("${arg0}") 
			|| args[1].equals("${arg1}")) {
			System.err.println("Error: Incorrect number of arguments. Program accepts 2 argumnets.");
			System.exit(0);
		}
		FileProcessor fp = new FileProcessor();
		
		CoursePlanner cp = new CoursePlanner(fp.readFile(args[0]));
		String studentResult = cp.planCourse();
		
		Results res = new Results();
		res.printResult(studentResult);
		res.writeResult(args[1], studentResult);
	}


	public String toString() {
		return "Driver";
	}
}
