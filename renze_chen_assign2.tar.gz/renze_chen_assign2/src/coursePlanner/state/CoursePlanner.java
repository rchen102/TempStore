package coursePlanner.state;

import java.util.List;


/*
 * The context class
 */
public class CoursePlanner {
	private State coursePlannerStateOne;
	private State coursePlannerStateTwo;
	private State coursePlannerStateThree;
	private State coursePlannerStateFour;
	private State coursePlannerStateFive;
	
	private State curState;
	private Student stu;
	private int semester;
	private int stateChange;
	
	public CoursePlanner(List<String> studentInfo) {
		this.stu = new Student(studentInfo);
		coursePlannerStateOne = new CoursePlannerStateOne(this);
		coursePlannerStateTwo = new CoursePlannerStateTwo(this);
		coursePlannerStateThree = new CoursePlannerStateThree(this);
		coursePlannerStateFour = new CoursePlannerStateFour(this);
		coursePlannerStateFive = new CoursePlannerStateFive(this);

		this.semester = 0;	
		this.stateChange = 0;
		this.curState = coursePlannerStateOne;
	}

	public String planCourse() {
		int i;
		boolean graduate = false;
		String res = this.stu.getId() + ":";
		List<Character> curSemesterCourse;

		while (!graduate) {
			this.stu.newSemester();
			this.semester++;
			for (i = 0; i < 3; i++) {
				if (this.curState.processOneCourse() == false) break;
				if (this.stu.satisfyGraduate()) {
					graduate = true;
					break;
				}
			}
			curSemesterCourse = this.stu.getCurSemesterCourse();
			for (char course : curSemesterCourse) {
				res += " " + Character.toString(course);
			}
			// Take less than 3 courses
			if (i != 3) break; 
		}
		
		if (graduate) {
			res += " -- " + this.semester + " " + this.stateChange;
			return res;
		} 
		else {
			this.semester = 0; // If student doesn't graduate, set #semester to 0
			res += " -- " + this.semester + " " + this.stateChange + "\nThe student cannot graduate.";
			return res;
		}
	}

	public void setState(State state) {
		this.curState = state;
		this.stateChange++;
	}

	public State getStateOne() {
		return this.coursePlannerStateOne;
	}

	public State getStateTwo() {
		return this.coursePlannerStateTwo;
	}

	public State getStateThree() {
		return this.coursePlannerStateThree;
	}

	public State getStateFour() {
		return this.coursePlannerStateFour;
	}

	public State getStateFive() {
		return this.coursePlannerStateFive;
	}

	public Student getStudent() {
		return this.stu;
	}

	public int getSemester() {
		return this.semester;
	}

	public int getStateChange() {
		return this.stateChange;
	}
}