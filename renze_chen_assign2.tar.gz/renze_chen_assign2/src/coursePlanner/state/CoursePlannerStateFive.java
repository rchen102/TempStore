package coursePlanner.state;

public class CoursePlannerStateFive implements State{
	CoursePlanner pl;

	public CoursePlannerStateFive(CoursePlanner pl) {
		this.pl = pl;
	}
	
	public boolean processOneCourse() {
		if (this.pl.getStudent().processNext() == false) return false;

		int group = this.pl.getStudent().groupMoreThan(5);
		switch(group) {
			case 1:
				this.pl.setState(pl.getStateOne());
				break;
			case 2:
				this.pl.setState(pl.getStateTwo());
				break;
			case 3:
				this.pl.setState(pl.getStateThree());
				break;
			case 4:
				this.pl.setState(pl.getStateFour());
				break;
		}
		return true;
	}
}