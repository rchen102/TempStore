package coursePlanner.state;

public class CoursePlannerStateFour implements State{
	CoursePlanner pl;

	public CoursePlannerStateFour(CoursePlanner pl) {
		this.pl = pl;
	}
	
	public boolean processOneCourse() {
		if (this.pl.getStudent().processNext() == false) return false;

		int group = this.pl.getStudent().groupMoreThan(4);
		switch(group) {
			case 1:
				this.pl.setState(pl.getStateOne());
				break;
			case 2:
				this.pl.setState(pl.getStateTwo());
				break;
			case 3:
				this.pl.setState(pl.getStateThree());
				break;
			case 5:
				this.pl.setState(pl.getStateFive());
				break;
		}
		return true;
	}
}