package coursePlanner.state;

public class CoursePlannerStateOne implements State{
	CoursePlanner pl;

	public CoursePlannerStateOne(CoursePlanner pl) {
		this.pl = pl;
	}

	public boolean processOneCourse() {
		if (this.pl.getStudent().processNext() == false) return false;

		int group = this.pl.getStudent().groupMoreThan(1);
		switch(group) {
			case 2:
				this.pl.setState(pl.getStateTwo());
				break;
			case 3:
				this.pl.setState(pl.getStateThree());
				break;
			case 4:
				this.pl.setState(pl.getStateFour());
				break;
			case 5:
				this.pl.setState(pl.getStateFive());
				break;
		}
		return true;
	}
}