package coursePlanner.state;

public class CoursePlannerStateThree implements State{
	CoursePlanner pl;
	
	public CoursePlannerStateThree(CoursePlanner pl) {
		this.pl = pl;
	}
	
	public boolean processOneCourse() {
		if (this.pl.getStudent().processNext() == false) return false;

		int group = this.pl.getStudent().groupMoreThan(3);
		switch(group) {
			case 1:
				this.pl.setState(pl.getStateOne());
				break;
			case 2:
				this.pl.setState(pl.getStateTwo());
				break;
			case 4:
				this.pl.setState(pl.getStateFour());
				break;
			case 5:
				this.pl.setState(pl.getStateFive());
				break;
		}
		return true;
	}

}