package coursePlanner.state;

/*
 * State interface
 */
public interface State {
	boolean processOneCourse();
}