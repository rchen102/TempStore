package coursePlanner.state;

import java.util.List;
import java.util.LinkedList;
import java.util.Set;
import java.util.HashSet;

public class Student {
	private int id;                      // Student Id
	private int[] courses = new int[26]; // If course taken, it will be set to 1
	
	private List<Character> curSemesterCourse;
	private List<Character> courseWaitList;
	
	public Student(List<String> list) {
		try {
			if (list.size() == 0) {
				throw new IllegalArgumentException("The input file is empty.");
			}
			
			String info = list.get(0);
			String[] stuInfo = info.split(": ");
			this.id = Integer.parseInt(stuInfo[0]);

			String[] courseInfo = stuInfo[1].split(" ");
			this.courseWaitList = new LinkedList<>();
			for (String str : courseInfo) {
				this.courseWaitList.add(str.charAt(0));
			}

			Set testDup = new HashSet(this.courseWaitList);
			if (testDup.size() != this.courseWaitList.size()) {
				throw new IllegalArgumentException("Duplicate courses exist.");
			}
		} catch(IllegalArgumentException e) {
			System.err.println("Error: the input file is illegal.");
			e.printStackTrace();
			System.exit(0);
		} finally {
		}
	}

	public int getId() {
		return this.id;
	}

	public List<Character> getCurSemesterCourse() {
		return this.curSemesterCourse;
	}

	public void newSemester() {
		this.curSemesterCourse = new LinkedList<>();
	}

	public boolean satisfyGraduate() {
		if (this.getCourseNumByGroup(1) >= 2 
				&& this.getCourseNumByGroup(2) >= 2
				&& this.getCourseNumByGroup(3) >= 2
				&& this.getCourseNumByGroup(4) >= 2
				&& this.getCourseNumByGroup(5) >= 2) {
			return true;
		}
		return false;
	}

	/*
	 * Check if course's pre-requisite has already been assigned this semester
	 * Return true if pre-req has already been assigned 
	 * Return false if not
	 */
	private boolean preReqInCurSemester(char course) {
		for (char ch : curSemesterCourse) {
			if (ch == (char)(course - 1)) return true;
		}
		return false;
	}

	/*
	 * return true if the student satisfy Pre-requisites for course
	 */
	private boolean satisfyPreReq(char course) {
		int num = course - 'A';
		if (num < 0 || num > 25) {
			System.out.println(course + "does not exist");
		}
		if (num == 0 || num == 4 || num == 8 || num == 12 || num >= 16) {
			return true;
		}
		if (courses[num - 1] == 1 && !preReqInCurSemester(course)) return true;
		return false;
	}

	/*
	 * Process next course for student from wait list
	 */
	public boolean processNext() {
		if (courseWaitList.size() == 0) return false;
		char course;
		for (int i = 0; i < courseWaitList.size(); i++) {
			course = courseWaitList.get(i);
			if (satisfyPreReq(course)) {
				courses[course - 'A'] = 1;  // Take the course
				courseWaitList.remove(i);   // Remove course from wait list
				curSemesterCourse.add(course);
				return true;
			}
		}
		return false;
	}

	/*
	 * Count the #course at group #group
	 */
	private int getCourseNumByGroup(int group) {
		int num = 0;
		switch (group) {
			case 1:
				for (int i = 0; i < 4; i++) {
					if (courses[i] == 1) num++;
				}
				break;

			case 2:
				for (int i = 4; i < 8; i++) {
					if (courses[i] == 1) num++;
				}
				break;

			case 3:
				for (int i = 8; i < 12; i++) {
					if (courses[i] == 1) num++;
				}
				break;

			case 4:
				for (int i = 12; i < 16; i++) {
					if (courses[i] == 1) num++;
				}
				break;			

			case 5:
				for (int i = 16; i < 25; i++) {
					if (courses[i] == 1) num++;
				}
				break;
		}
		return num;
	}


	/*
	 * Return the #group where #course student has taken is more than #curGroup
	 * If no such group, only return #curGroup
	 */		
	public int groupMoreThan(int curGroup) {
		int curMax = this.getCourseNumByGroup(curGroup);

		for (int i = 1; i <= 5; i++) {
			if (i == curGroup) continue;
			if (this.getCourseNumByGroup(i) > curMax) {
				return i;
			}
		}
		return curGroup;
	}
}