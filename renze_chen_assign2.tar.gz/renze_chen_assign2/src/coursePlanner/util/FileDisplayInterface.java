package coursePlanner.util;

public interface FileDisplayInterface {
	void showFileContent(String fileName);
}
