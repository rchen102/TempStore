package coursePlanner.util;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;


public class FileProcessor {

	public List<String> readFile(String fileName) {
		List<String> readInfo = new ArrayList<String>();
		try (Scanner sc = new Scanner(new File(fileName))) {
			while (sc.hasNext()) {
				String line = sc.nextLine();
				readInfo.add(line);
			}			
		}
		catch (FileNotFoundException e){
			System.err.println("Error: File '" + fileName + "' not found.");
			System.err.println("Please check README for correct place to place file.");
			e.printStackTrace();
			System.exit(0);
		}
		catch (Exception e){
			System.err.println("Error occurred while reading file:");
			System.err.println("Please check README for correct file format.");
			e.printStackTrace();
			System.exit(0);
		} finally {
		}
		return readInfo;
	}

	public void writeFile(String fileName, List<String> result) {
		try (FileWriter fw = new FileWriter(new File(fileName))) {
			for (String line : result) {
				fw.write(line);
			}
		} catch (Exception e){
			System.err.println("Error occurred while writing file:");
			System.exit(0);
		} finally {
		}
	}

	public void writeFile(String fileName, String result) {
		try (FileWriter fw = new FileWriter(new File(fileName))) {
			fw.write(result);
		} catch (Exception e){
			System.err.println("Error occurred while writing file:");
			System.exit(0);
		} finally {
		}
	}
	
	public String toString() {
		return "FileProcessor";
	}
}
