package coursePlanner.util;

import java.util.List;
import java.util.ArrayList;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	public void writeResult(String fileName, List<String> res) {
		System.out.println("Results have been written into File '" + fileName + "'.");
		FileProcessor fp = new FileProcessor();
		fp.writeFile(fileName, res);
	}

	public void writeResult(String fileName, String res) {
		System.out.println("Results have been written into File '" + fileName + "'.");
		FileProcessor fp = new FileProcessor();
		fp.writeFile(fileName, res);
	}

	public void showFileContent (String fileName) {
		FileProcessor fp = new FileProcessor();
		List<String> lines = fp.readFile(fileName);
		System.out.println("\n------Show '" + fileName + "' start------");
		for (String line : lines) {
			System.out.println(line);
		}
		System.out.println("------Show '" + fileName + "' done------");
	}

	public void printResult(List<String> res) {
		System.out.println("\n------Print results start------");
		for (String str : res) {
			System.out.println(str);
		}
		System.out.println("------Print results done-------");
	}

	public void printResult(String str) {
		System.out.println("\n------Print results start------");
		System.out.println(str);
		System.out.println("------Print results done-------");
	}

	public String toString() {
		return "Results";
	}
}
