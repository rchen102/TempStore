package coursePlanner.util;

import java.util.List;

public interface StdoutDisplayInterface {
	void printResult(List<String> res);
	void printResult(String res);
}
