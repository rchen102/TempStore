# CSX42: Assignment 4
## Name 
Renze Chen

## Slack Day
Use one slack day for assignment 4

## Running
Following are the commands and the instructions to run ANT on this project.

1. __Instruction to compile__
   ```shell
   ant -buildfile troubleShootSearch/src/build.xml all
   ```
   Compiles your code and generates `.class` files inside the BUILD folder.

2. __Instruction to run__
   ```shell
   ant -buildfile troubleShootSearch/src/build.xml run -Darg0="files/technicalInfo.txt" -Darg1="files/synonyms.txt" -Darg2="files/userInput.txt" -Darg3="files/output.txt"
   ```
   Note: to run successfully, please place related files under folder  
   `/renze_chen_assign3/troubleShootSearch/files`  
   
3. __Instruction to clean__
   ```shell
   ant -buildfile troubleShootSearch/src/build.xml clean
   ```
   It cleans up all the `.class` files that were generated when you
compiled your code.

## Assumption
1. One synonym per word for keyword/key-phrase
2. For search results of _Naive Stemming Match_, repeated line numbers will only appear once

## Data Structure
- __MyArrayList__: use `ArrayList` to store product information
- __MyTree__: use `Binary Search Tree` to store words, use `TreeSet` to store line numbers for each word
- __SynonymList__: use `HashMap` to store synonym pair `<word, synonym>` and `<synonym, word>`

## Description
The program require __four__ files as arguments, the __four__ files should be given as following order

1. `technicalInfo.txt`: product information, line by line
2. `synonyms.txt`: synonyms in the format `<word>=<synonym>`
3. `userInput.txt`: keywords or key-phrases provided by users, one entry per line
4. `output.txt`: the search results

For each input entry, the search results will be given in the following format

User input entry example:  `problem detecting`

Results:

```text
user input - problem detecting  
Exact Match
-----------
1. If Debian has a problem detecting the drive, it could be that the portable drive is not receiving enough power.

Naive Stemming Match
-----------
No naive stemming match

Semantic Match
-----------
No semantic match

**********************************
```

## Exception handle
- __Any input file not found__: terminate and print error message, stack trace
- __Output file not found__: create new output file
- __`userInput.txt` is empty or contain only empty spaces__: empty output file will be given
- __Leading or trailing spaces exist in the user input entry__: eliminates leading and trailing spaces, then process the entry
- __Only Empty space in the user input entry__: skip the entry
- __Format of `synonyms.txt` is not correct__:  terminate and print error message

## Debug
For this project, we use `MyLogger` for debug, there is five debug levels, default level is `0`
- `0 = NONE`: No output should be printed. Only error messages will be printed 
- `1 = SEARCH_RESULTS`: Only the search results will be printed
- `2 = EXACT_MATCH`: Only information about _Exact Match_ will be printed (like keywords, search results)
- `3 = NAIVE_MATCH`: Only information about _Naive Stemming Match_ will be printed (like keywords, search results)
- `4 = SEMANTIC_MATCH`: Only information about _Semantic Match_ will be printed (like keywords, search results)

## Academic Honesty statement
"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

__Name__: Renze Chen __Date__: [2019/11/17]

