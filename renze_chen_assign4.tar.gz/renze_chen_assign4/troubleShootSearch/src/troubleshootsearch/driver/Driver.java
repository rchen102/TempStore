package troubleshootsearch.driver;

import troubleshootsearch.util.Results;
import troubleshootsearch.util.FileProcessor;
import troubleshootsearch.util.MyLogger;
import troubleshootsearch.troubleshooting.TroubleShooter;

/**
 * @author Renze Chen
 *
 */
public class Driver {
	public static void main(String[] args) {
		if (args.length != 4 || args[0].equals("${arg0}") 
			|| args[1].equals("${arg1}")
			|| args[2].equals("${arg2}")
			|| args[3].equals("${arg3}") ) {
			System.err.println("Error: Incorrect number of arguments. Program accepts 4 argumnets.");
			System.exit(0);
		}
		MyLogger.setDebugValue(MyLogger.DebugLevel.NONE);
		Results res = new Results(args[3]);
		TroubleShooter ts = new TroubleShooter(args[0], args[1], res);
		ts.processUserInput(args[2]);
	}


	public String toString() {
		return "Driver";
	}
}
