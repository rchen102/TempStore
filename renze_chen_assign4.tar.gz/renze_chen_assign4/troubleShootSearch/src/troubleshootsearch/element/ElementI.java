package troubleshootsearch.element;

import troubleshootsearch.visitor.VisitorI;

public interface ElementI {
	public void accept(VisitorI visitor);
}