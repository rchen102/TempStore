package troubleshootsearch.element;

import java.util.List;
import java.util.ArrayList;

import troubleshootsearch.visitor.VisitorI;

public class MyArrayList implements ElementI {

	private List<String> techInfo;

	public MyArrayList(List<String> techInfo) {
		this.techInfo = techInfo;
	}

	public List<String> getTechInfo() {
		return this.techInfo;
	}

	// Search for exact match for the entered keyword/key-phrase
	// Will be moved to visitor later
	public List<String> search(String keyword) {
		List<String> res = new ArrayList<>();
		for (String line : techInfo) {
			if (line.contains(keyword)) res.add(line);
		}
		return res;
	}

	@Override
	public void accept(VisitorI visitor) {
		visitor.visit(this);
	}
}