package troubleshootsearch.element;

import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;

import troubleshootsearch.visitor.VisitorI;

public class MyTree implements ElementI {
	private Node root;

	public MyTree(List<String> fileInfo) {
		this.root = null;
		this.buildTree(fileInfo);
	}

	public void buildTree(List<String> fileInfo) {
		int num = 0;
		for (String line : fileInfo) {
			num++;
			StringTokenizer st = new StringTokenizer(line, " ,?.!:\"\"''\n#");
			while (st.hasMoreElements()) {
			    this.insert(st.nextToken(), num);
			}
		}
	}

	public Node getRoot() {
		return this.root;
	}

	public void insert(String word, int lineNumber) {
		if (this.root == null) this.root = new Node(word, lineNumber);
		else this.root.insert(word, lineNumber);
	}

	@Override
	public void accept(VisitorI visitor) {
		visitor.visit(this);
	}
}