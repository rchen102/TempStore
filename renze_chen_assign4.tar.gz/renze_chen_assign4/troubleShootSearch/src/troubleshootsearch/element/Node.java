package troubleshootsearch.element;

import java.util.Set;
import java.util.TreeSet;

public class Node implements Comparable<Node> {
	private String word;
	private Set<Integer> lineNumbers;
	
	public Node left;
	public Node right;

	public Node(String word, int lineNumber) {
		this.word = word;
		this.lineNumbers = new TreeSet<>();
		this.lineNumbers.add(lineNumber);
		this.left = null;
		this.right = null;
	}

	public String getWord() {
		return this.word;
	}

	public Set<Integer> getLineNumbers() {
		return this.lineNumbers;
	}

	public void addLineNumber(int lineNumber) {
		this.lineNumbers.add(lineNumber);
	}

	public void insert(String word, int lineNumber) {
		if (this.word.compareTo(word) == 0) {
			this.addLineNumber(lineNumber);
		} 
		else if (this.word.compareTo(word) > 0) {
			if (this.left == null) this.left = new Node(word, lineNumber);
			else this.left.insert(word, lineNumber);
		} 
		else {
			if (this.right == null) this.right = new Node(word, lineNumber);
			else this.right.insert(word, lineNumber);
		}
	}

	@Override
	public int compareTo(Node node) {
		return this.word.compareTo(node.getWord());
	}
}
