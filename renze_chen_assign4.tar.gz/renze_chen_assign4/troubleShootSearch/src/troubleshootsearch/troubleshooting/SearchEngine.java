package troubleshootsearch.troubleshooting;

import troubleshootsearch.element.ElementI;
import troubleshootsearch.element.MyArrayList;
import troubleshootsearch.element.MyTree;

import troubleshootsearch.visitor.VisitorI;
import troubleshootsearch.visitor.ExactMatchVisitor;
import troubleshootsearch.visitor.NaiveStemmingMatchVisitor;
import troubleshootsearch.visitor.SemanticMatchVisitor;

import troubleshootsearch.util.FileProcessor;
import troubleshootsearch.util.Results;
import troubleshootsearch.util.MyLogger;

public class SearchEngine {
	private ElementI myArrayList;
	private ElementI myTree;
	private SynonymList synonymList;

	private VisitorI exactMatchVisitor;
	private VisitorI naiveStemmingMatchVisitor;
	private VisitorI semanticMatchVisitor;

	private Results res;

	public SearchEngine(String technicalInfoFile, String synonymsFIle, Results res) {
		this.res = res;
		buildAndAddMyArrayList(technicalInfoFile);
		buildAndAddMyTree(technicalInfoFile);
		buildSynonymList(synonymsFIle);
	}

	public void processOneEntry(String keyword) {
		keyword = keyword.trim();
		keyword = keyword.toLowerCase();

		this.exactMatchVisitor = new ExactMatchVisitor(keyword, res);
		this.naiveStemmingMatchVisitor = new NaiveStemmingMatchVisitor(keyword, res);
		this.semanticMatchVisitor = new SemanticMatchVisitor(keyword, res, this.synonymList);
		
		// Visit Element
		this.res.writeResult("Exact Match\n");
		this.res.writeResult("-----------\n");
		this.myArrayList.accept(this.exactMatchVisitor);
		this.res.writeResult("\n");

		this.res.writeResult("Naive Stemming Match\n");
		this.res.writeResult("-----------\n");
		this.myTree.accept(this.naiveStemmingMatchVisitor);
		this.res.writeResult("\n");

		this.res.writeResult("Semantic Match\n");
		this.res.writeResult("-----------\n");
		this.myArrayList.accept(this.semanticMatchVisitor);
		this.res.writeResult("\n");
	}

	public void buildAndAddMyArrayList(String technicalInfoFile) {
		FileProcessor fp = new FileProcessor();
		fp.setScannerForFile(technicalInfoFile);
		this.myArrayList = new MyArrayList(fp.readAllFromFile());
	}

	public void buildAndAddMyTree(String technicalInfoFile) {
		FileProcessor fp = new FileProcessor();
		fp.setScannerForFile(technicalInfoFile);
		this.myTree = new MyTree(fp.readAllFromFile());
	}

	public void buildSynonymList(String synonymsFIle) {
		this.synonymList = new SynonymList();
		FileProcessor fp = new FileProcessor();
		fp.setScannerForFile(synonymsFIle);
		while (fp.hasNext()) {
			String line = fp.readOneLineFromFile();
			String[] words = line.split("=");
			if (words.length != 2) {
				MyLogger.writeMessage("Error: Format of '" + synonymsFIle + "' is not corrrect", MyLogger.DebugLevel.NONE);
				System.exit(0);
			}
			this.synonymList.addSynonym(words[0].toLowerCase(), words[1].toLowerCase());
		}
	}

}