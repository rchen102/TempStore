package troubleshootsearch.troubleshooting;

import java.util.Map;
import java.util.HashMap;

public class SynonymList {
	private Map<String, String> map;

	public SynonymList() {
		this.map = new HashMap<>();
	}

	public void addSynonym(String word, String synonym) {
		if (!this.map.containsKey(word)) {
			this.map.put(word, synonym);
		}
		if (!this.map.containsKey(synonym)) {
			this.map.put(synonym, word);
		}
	}

	public boolean hasSynonym(String word) {
		return this.map.containsKey(word);
	}

	public String getSynonym(String word) {
		return this.map.get(word);
	}
}