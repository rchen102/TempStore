package troubleshootsearch.troubleshooting;

import troubleshootsearch.util.FileProcessor;
import troubleshootsearch.util.Results;
import troubleshootsearch.util.MyLogger;

public class TroubleShooter {
	private SearchEngine se;
	private Results res;

	public TroubleShooter(String technicalInfoFile, String synonymsFIle, Results res) {
		this.se = new SearchEngine(technicalInfoFile, synonymsFIle, res);
		this.res = res;
	}

	public void processUserInput(String userInputFIle) {
		FileProcessor fp = new FileProcessor();
		fp.setScannerForFile(userInputFIle);
		while (fp.hasNext()) {
			String keywords = fp.readOneLineFromFile();
			if (keywords.length() == 0 || keywords.trim().length() == 0) continue;

			MyLogger.writeMessage("-----Search results for '" + keywords + "'-----", MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage("-----Keywords is '" + keywords + "'-----", MyLogger.DebugLevel.EXACT_MATCH);
			MyLogger.writeMessage("-----Keywords is '" + keywords + "'-----", MyLogger.DebugLevel.NAIVE_MATCH);
			MyLogger.writeMessage("-----Keywords is '" + keywords + "'-----", MyLogger.DebugLevel.SEMANTIC_MATCH);

			res.writeResult("user input - " + keywords + "\n");
			this.se.processOneEntry(keywords);
			res.writeResult("**********************************\n");
		}
	}
}