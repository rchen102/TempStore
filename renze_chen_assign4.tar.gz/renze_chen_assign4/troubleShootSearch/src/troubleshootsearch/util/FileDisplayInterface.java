package troubleshootsearch.util;

public interface FileDisplayInterface {
	void showFileContent();
}
