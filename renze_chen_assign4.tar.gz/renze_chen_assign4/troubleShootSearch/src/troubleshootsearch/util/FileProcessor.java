package troubleshootsearch.util;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;


public class FileProcessor {
	private Scanner sc = null;

	public void setScannerForFile(String fileName) {
		if (this.sc != null) {
			this.sc.close();
			this.sc = null;
		}
		try {
			this.sc = new Scanner(new File(fileName));
		} 
		catch (FileNotFoundException e) {
			MyLogger.writeMessage("Error: File '" + fileName + "' not found.", MyLogger.DebugLevel.NONE);
			MyLogger.writeMessage("Please check fileName and correct directory to place file.", MyLogger.DebugLevel.NONE);
			e.printStackTrace();
			System.exit(0);
		} 
		finally {
		}
	}

	public boolean hasNext() {
		if (this.sc == null) return false;
		if (this.sc.hasNext() == false) {
			this.sc.close();
			return false;
		}
		return true;
	}

	public List<String> readAllFromFile() {
		List<String> readInfo = new ArrayList<String>();
		if (this.sc == null) return readInfo;
		try {
			while (this.hasNext()) {
				String line = this.sc.nextLine();
				readInfo.add(line);
			}
		} 
		catch (Exception e) {
			MyLogger.writeMessage("Error occurred while reading file.", MyLogger.DebugLevel.NONE);
			e.printStackTrace();
			System.exit(0);
		} 
		finally {
		}
		return readInfo;
	}

	public String readOneLineFromFile() {
		if (!this.hasNext()) return "";
		return this.sc.nextLine();
	}

	public void wrieFileAppend(String fileName, String str) {
		try (FileWriter fw = new FileWriter(new File(fileName), true)) {
			fw.write(str);
		} catch (Exception e){
			MyLogger.writeMessage("Error occurred while writing file.", MyLogger.DebugLevel.NONE);
			System.exit(0);
		} finally {
		}
	}

	public void writeFile(String fileName, String result) {
		try (FileWriter fw = new FileWriter(new File(fileName))) {
			fw.write(result);
		} catch (Exception e){
			MyLogger.writeMessage("Error occurred while writing file.", MyLogger.DebugLevel.NONE);
			System.exit(0);
		} finally {
		}
	}

	public void writeFile(String fileName, List<String> result) {
		try (FileWriter fw = new FileWriter(new File(fileName))) {
			for (String line : result) {
				fw.write(line);
			}
		} catch (Exception e){
			MyLogger.writeMessage("Error occurred while writing file.", MyLogger.DebugLevel.NONE);
			System.exit(0);
		} finally {
		}
	}
	
	public String toString() {
		return "FileProcessor";
	}
}
