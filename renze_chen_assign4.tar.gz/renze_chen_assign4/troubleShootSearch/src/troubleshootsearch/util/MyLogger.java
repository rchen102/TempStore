package troubleshootsearch.util;

public class MyLogger {
	public static enum DebugLevel { 
		NONE,            // 0
		SEARCH_RESULTS,  // 1
		EXACT_MATCH,     // 2 
		NAIVE_MATCH,     // 3
		SEMANTIC_MATCH   // 4
	};

	private static DebugLevel debugLevel;

	public static void setDebugValue (int levelIn) {
		switch (levelIn) {
			case 0: debugLevel = DebugLevel.NONE; break;
			case 1: debugLevel = DebugLevel.SEARCH_RESULTS; break;
			case 2: debugLevel = DebugLevel.EXACT_MATCH; break;
			case 3: debugLevel = DebugLevel.NAIVE_MATCH; break;
			case 4: debugLevel = DebugLevel.SEMANTIC_MATCH; break;
			default: debugLevel = DebugLevel.NONE; break;
		}
    }

    public static void setDebugValue (DebugLevel levelIn) {
		debugLevel = levelIn;
    }

    public static void writeMessage (String message, DebugLevel levelIn ) {
		if (levelIn == debugLevel) System.out.println(message);
    }

    public String toString() {
		return "The debug level has been set to the following " + debugLevel;
    }
}