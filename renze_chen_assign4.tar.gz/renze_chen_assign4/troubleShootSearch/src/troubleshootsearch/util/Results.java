package troubleshootsearch.util;

import java.util.List;
import java.util.ArrayList;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	private String fileName;
	private FileProcessor fp;

	public Results(String fileName) {
		this.fileName = fileName;
		this.fp = new FileProcessor();
		fp.writeFile(fileName, "");    // Initialize the output file
	}

	public void writeResult(String res) {
		fp.wrieFileAppend(this.fileName, res);
	}

	public void showFileContent () {
		this.fp.setScannerForFile(this.fileName);
		System.out.println("\n------Show '" + this.fileName + "' start------");
		while (this.fp.hasNext()) {
			System.out.println(this.fp.readOneLineFromFile());
		}
		System.out.println("------Show '" + this.fileName + "' done------");
	}

	public void printResult(List<String> res) {
		System.out.println("\n------Print results start------");
		for (String str : res) {
			System.out.println(str);
		}
		System.out.println("------Print results done-------");
	}

	public String toString() {
		return "Results";
	}
}
