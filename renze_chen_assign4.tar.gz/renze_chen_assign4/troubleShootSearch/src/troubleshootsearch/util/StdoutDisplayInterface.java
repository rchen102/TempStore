package troubleshootsearch.util;

import java.util.List;

public interface StdoutDisplayInterface {
	void printResult(List<String> res);
}
