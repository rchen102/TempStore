package troubleshootsearch.visitor;

import java.util.List;

import troubleshootsearch.element.MyTree;
import troubleshootsearch.element.MyArrayList;
import troubleshootsearch.util.Results;
import troubleshootsearch.util.MyLogger;


public class ExactMatchVisitor implements VisitorI {

	private String keyword; 
	private Results res;

	public ExactMatchVisitor(String keywordIn, Results res) {
		this.res = res;
		this.setKeyword(keywordIn);
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public void visit(MyArrayList myArrayList) {
		int num = 0;
		List<String> techInfo = myArrayList.getTechInfo();
		for (String line : techInfo) {
			String transformedLine = line.toLowerCase();
			int start = transformedLine.indexOf(this.keyword);
			if (start < 0) continue;

			int left = start - 1;                   // left boundary 
			int right = start + this.keyword.length();   // right boundary
			if (left >= 0 && transformedLine.charAt(left) >= 'a' && transformedLine.charAt(left) <= 'z') continue;
			if (right <= transformedLine.length()-1 && transformedLine.charAt(right) >= 'a' && transformedLine.charAt(right) <= 'z') continue;

			num++;
			res.writeResult(num + ". " + line + "\n");
			MyLogger.writeMessage(num + ". " + line, MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage(num + ". " + line, MyLogger.DebugLevel.EXACT_MATCH);
		}
		if (num == 0) {
			res.writeResult("No exact match\n");
			MyLogger.writeMessage("No exact match", MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage("No exact match", MyLogger.DebugLevel.EXACT_MATCH);
		}
	}

	public void visit(MyTree myTree) {
		// do nothing
	}
}