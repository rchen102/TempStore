package troubleshootsearch.visitor;

import java.util.Set;
import java.util.TreeSet;

import troubleshootsearch.element.Node;
import troubleshootsearch.element.MyTree;
import troubleshootsearch.element.MyArrayList;
import troubleshootsearch.util.Results;
import troubleshootsearch.util.MyLogger;


public class NaiveStemmingMatchVisitor implements VisitorI {
	private String keyword; 
	private Results res;

	public NaiveStemmingMatchVisitor(String keywordIn, Results res) {
		this.res = res;
		this.setKeyword(keywordIn);
	}

	public void setKeyword(String keyword) {
		String[] keywords = keyword.split(" ");
		this.keyword = keywords[0];
	}

	public void visit(MyTree myTree) {
		Set<Integer> lineNumbers = new TreeSet<>();
		int wordCount = visitHelper(myTree.getRoot(), lineNumbers);

		if (wordCount == 0) {
			res.writeResult("No naive stemming match\n");
			MyLogger.writeMessage("No naive stemming match", MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage("No naive stemming match", MyLogger.DebugLevel.NAIVE_MATCH);
		}
		else {
			res.writeResult("Word Count = " + wordCount + "\n");
			MyLogger.writeMessage("Word Count = " + wordCount, MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage("Word Count = " + wordCount, MyLogger.DebugLevel.NAIVE_MATCH);

			int i = 0;
			String tmp = "Line Numbers = ";
			for (int lineNumber : lineNumbers) {
				if (i != 0) tmp += "," + lineNumber;
				else {
					tmp += lineNumber;
					i++;
				}
			}
			res.writeResult(tmp + "\n");
			MyLogger.writeMessage(tmp, MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage(tmp, MyLogger.DebugLevel.NAIVE_MATCH);
		}
	}

	public int visitHelper(Node node, Set<Integer> lineNumbers) {
		if (node == null) return 0;
		int wordCount1 = visitHelper(node.left, lineNumbers);
		int wordCount2 = visitHelper(node.right, lineNumbers);
		String nodeWord = node.getWord().toLowerCase();
		if (nodeWord.contains(this.keyword) && nodeWord.compareTo(this.keyword) != 0) {
			lineNumbers.addAll(node.getLineNumbers());
			return wordCount1 + wordCount2 + 1;
		}
		return wordCount1 + wordCount2;
	}

	public void visit(MyArrayList myArrayList) {
		// do nothing
	}
}