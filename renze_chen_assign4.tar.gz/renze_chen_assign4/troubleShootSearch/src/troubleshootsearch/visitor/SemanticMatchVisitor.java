package troubleshootsearch.visitor;

import java.util.List;

import troubleshootsearch.troubleshooting.SynonymList;
import troubleshootsearch.element.MyTree;
import troubleshootsearch.element.MyArrayList;
import troubleshootsearch.util.Results;
import troubleshootsearch.util.MyLogger;


public class SemanticMatchVisitor implements VisitorI {
	private String keyword; 
	private Results res;
	private SynonymList synonymList;
	private boolean synonymExist = false;

	public SemanticMatchVisitor(String keywordIn, Results res, SynonymList synonymList) {
		this.res = res;
		this.synonymList = synonymList;
		this.setKeyword(keywordIn);
	}

	public void setKeyword(String keywordIn) {
		String[] keywords = keywordIn.split(" ");
		int length = keywords.length;
		String lastKeyword = keywords[length - 1];

		if (synonymList.hasSynonym(lastKeyword)) {
			this.synonymExist = true;
			String synonym = synonymList.getSynonym(lastKeyword);
			if (length == 1) this.keyword = synonym;
			else {
				this.keyword =  keywordIn.substring(0, keywordIn.length() - lastKeyword.length()) + synonym;
			}
		}
	}

	public void visit(MyArrayList myArrayList) {
		if (synonymExist) {
			MyLogger.writeMessage("Synonym exist", MyLogger.DebugLevel.SEMANTIC_MATCH);
			MyLogger.writeMessage("After synonym replaced, keywords = '" + this.keyword + "'", MyLogger.DebugLevel.SEMANTIC_MATCH);
			int num = 0;
			List<String> techInfo = myArrayList.getTechInfo();
			for (String line : techInfo) {
				String transformedLine = line.toLowerCase();
				int start = transformedLine.indexOf(this.keyword);
				if (start < 0) continue;

				int left = start - 1;                   // left boundary 
				int right = start + this.keyword.length();   // right boundary
				if (left >= 0 && transformedLine.charAt(left) >= 'a' && transformedLine.charAt(left) <= 'z') continue;
				if (right <= transformedLine.length()-1 && transformedLine.charAt(right) >= 'a' && transformedLine.charAt(right) <= 'z') continue;

				num++;
				res.writeResult(num + ". " + line + "\n");
				MyLogger.writeMessage(num + ". " + line, MyLogger.DebugLevel.SEARCH_RESULTS);
				MyLogger.writeMessage(num + ". " + line, MyLogger.DebugLevel.SEMANTIC_MATCH);
			}
			if (num == 0) {
				res.writeResult("No semantic match\n");
				MyLogger.writeMessage("No semantic match", MyLogger.DebugLevel.SEARCH_RESULTS);
				MyLogger.writeMessage("No semantic match", MyLogger.DebugLevel.SEMANTIC_MATCH);
			}
		} else {
			res.writeResult("No semantic match\n");
			MyLogger.writeMessage("No semantic match", MyLogger.DebugLevel.SEARCH_RESULTS);
			MyLogger.writeMessage("No semantic match", MyLogger.DebugLevel.SEMANTIC_MATCH);
		}
	}

	public void visit(MyTree myTree) {
		// do nothing
	}
}