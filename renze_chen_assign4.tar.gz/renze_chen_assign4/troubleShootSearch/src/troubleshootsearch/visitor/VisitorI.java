package troubleshootsearch.visitor;

import troubleshootsearch.element.MyTree;
import troubleshootsearch.element.MyArrayList;

public interface VisitorI {
	void visit(MyArrayList myArrayList);
	void visit(MyTree myTree);
}