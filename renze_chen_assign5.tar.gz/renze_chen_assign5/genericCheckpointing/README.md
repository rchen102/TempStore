# CSX42: Assignment 5
## Academic Honesty Policy 
"This assignment's submission is my own work and I did not discuss with any other past or current student, nor did I have access to a previous submission of this assignment by another student."

__Name__: Renze Chen __Date__: [2019/12/5]

## Name 
Renze Chen

## Slack Day
Use rest slack day(2 days) for assignment 5

## Running
Following are the commands and the instructions to run ANT on this project.

1. __Instruction to compile__
   ```shell
   ant -buildfile genericCheckpointing/src/build.xml all
   ```
   Compiles the code and generates `.class` files inside the `BUILD/` folder.

2. __Instruction to run__
   ```shell
   ant -buildfile genericCheckpointing/src/build.xml run -Darg0="deserser" -Darg1="files/MyAllTypes.txt" -Darg2="files/Output.txt" -Darg3="default"
   ```
   Note: to run successfully, please place related files under folder  
   `/renze_chen_assign5/genericCheckpointing/files` and __change file names__ accordingly

3. __Instruction to clean__
   ```shell
   ant -buildfile genericCheckpointing/src/build.xml clean
   ```
   It cleans up all the `.class` files that were generated when you
compiled your code.

## Assumption
1. For deserialization, the `checkpoint` file should be well formatted
   - Correct tagname and tag be well paired 
   - Data member's content should match the data type

2. For serialization, in `checkpoint-verify` file,
   - Fields can be written in a different order from `checkpoint` file
   - Every field will be serialized (i.e., for same object, there may be more fields than `checkpoint` file)

3. Currently, the types of data member(i.e., field) are limited to 
   - `byte`
   - `short`
   - `int`
   - `long`
   - `float`
   - `double`
   - `char`
   - `String`

## Description
The program require __four__ arguments, which should be given as following order
1. __mode__: for current program, it only surpports one mode `deserser`
2. __checkpoint file name__: the file to be deserialized
3. __checkpoint-verify file name__: serialize objects into the verify file
4. __debug__: debug value

## Exception handle
- __Checkpoint file not found__: terminate and print error message, stack trace
- __Checkpoint-verify file not found__: create a new one automatically
- __Not formatted line in checkpoint file__: like empty line, just skip the line
- __NoSuchMethodException, IllegalAccessException, InvocationTargetException__: terminate and print error message, stack trace

## Debug
The current program only takes default debug level (i.e., debug value is set to `default`)

No output should be printed. Only error messages will be printed

## Academic Honesty statement
"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

__Name__: Renze Chen __Date__: [2019/12/5]

