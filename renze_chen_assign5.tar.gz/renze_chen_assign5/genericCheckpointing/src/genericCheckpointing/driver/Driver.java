package genericCheckpointing.driver;

import java.util.List;

import genericCheckpointing.util.ProxyCreator;
import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.server.RestoreI;
import genericCheckpointing.server.StoreI;
import genericCheckpointing.server.StoreRestoreI;
import genericCheckpointing.xmlStoreRestore.StoreRestoreHandler;

import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.MySpecialTypes;

/**
 * @author Renze Chen
 *
 */
public class Driver {
	public static void main(String[] args) {
		if (args.length != 4 || args[0].equals("${arg0}") 
			|| args[1].equals("${arg1}")
			|| args[2].equals("${arg2}")
			|| args[3].equals("${arg3}") ) {
			System.err.println("Error: Incorrect number of arguments. Program accepts 4 argumnets.");
			System.exit(0);
		}
		if (!args[0].equals("deserser")) {
			System.err.println("Error: Incorrect mode, only support 'deserser' mode.");
			System.exit(0);
		}
		
		StoreRestoreHandler srHandler = new StoreRestoreHandler();

		// Set and open checkpoint file and checkpoint-verify file
		srHandler.setAndOpenCpointFile(args[1]);
		srHandler.setAndOpenVerifyFile(args[2]);

		// Create Proxy
		ProxyCreator pc = new ProxyCreator();
		StoreRestoreI cpointRef = (StoreRestoreI) pc.createProxy(
			new Class[] {StoreI.class, RestoreI.class}, 
			srHandler);

		// Deserialize checkpoint file
		List<SerializableObject> myRecord = ((RestoreI)cpointRef).readObj("XML");

		// Serialize list of objects to checkpoint-verify file
		for (SerializableObject sObj : myRecord) {
			if (sObj instanceof MyAllTypesFirst) {
				MyAllTypesFirst myFirst = (MyAllTypesFirst) sObj;
				((StoreI) cpointRef).writeObj(myFirst, "XML");
			}
			if (sObj instanceof MySpecialTypes) {
				MySpecialTypes mySpecial = (MySpecialTypes) sObj;
				((StoreI) cpointRef).writeObj(mySpecial, "XML");
			}
		}

		// Close checkpoint file and checkpoint-verify file
		srHandler.closeCpointFile();
		srHandler.closeVerifyFile();
	}


	public String toString() {
		return "Driver";
	}
}
