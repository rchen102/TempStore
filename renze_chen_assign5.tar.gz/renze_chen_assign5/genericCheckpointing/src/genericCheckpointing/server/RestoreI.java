package genericCheckpointing.server;

import java.util.List;
import genericCheckpointing.util.SerializableObject;

public interface RestoreI extends StoreRestoreI {
    List<SerializableObject> readObj(String fileName);
}