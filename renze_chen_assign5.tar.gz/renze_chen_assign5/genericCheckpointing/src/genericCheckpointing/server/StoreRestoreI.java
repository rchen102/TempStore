package genericCheckpointing.server;

/*
 * Tag interface
 */
public interface StoreRestoreI {
}