package genericCheckpointing.util;

public class SerializableObject {

}