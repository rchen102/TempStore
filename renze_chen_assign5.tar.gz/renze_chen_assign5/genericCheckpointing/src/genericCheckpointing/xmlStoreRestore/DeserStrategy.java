package genericCheckpointing.xmlStoreRestore;

import java.util.List;

import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.SerializableObject;

public interface DeserStrategy {
	List<SerializableObject> processInput(FileProcessor fp);
}