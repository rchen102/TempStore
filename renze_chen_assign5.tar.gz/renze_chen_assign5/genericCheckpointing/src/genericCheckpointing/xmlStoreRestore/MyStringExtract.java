package genericCheckpointing.xmlStoreRestore;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Helper class for XMLDeserialization strategy
 * Responsible to extract target string with regular expression
 */
public class MyStringExtract {

    public static String extractClassName(String xml) {
        String nameOfClass = "";
        String rgex = "\"(.*?)\"";
        Pattern pattern = Pattern.compile(rgex);
        Matcher m = pattern.matcher(xml);
        m.find();
        nameOfClass = m.group(1);
        return nameOfClass;
    }

    public static String extractValue(String xml) {
        String value = "";
        String rgex = ">(.*?)</";
        Pattern pattern = Pattern.compile(rgex);
        Matcher m = pattern.matcher(xml);
        m.find();
        value = m.group(1);
        return value;
    }

    public static String extractFieldName(String xml) {
        String fieldName = "";
        String rgex = "<(.*?) xsi:type";
        Pattern pattern = Pattern.compile(rgex);
        Matcher m = pattern.matcher(xml);
        m.find();
        fieldName = m.group(1);
        return fieldName;
    }

    public static String extractFieldType(String xml) {
        String fieldType = "";
        String rgex = "xsi:type=\"xsd:(.*?)\"";
        Pattern pattern = Pattern.compile(rgex);
        Matcher m = pattern.matcher(xml);
        m.find();
        fieldType = m.group(1);
        return fieldType;
    }
}