package genericCheckpointing.xmlStoreRestore;

import java.util.List;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.SerializableObject;

public class StoreRestoreHandler implements InvocationHandler {

	private String cpointFile;
	private String verifyFile;

	public FileProcessor fpForCpointFile;
	public FileProcessor fpForVerifyFile;

	@Override
	public Object invoke(Object proxy, Method method, Object[] params) throws Throwable {
		String methodName= method.getName();
		// Handle read operation
		if ("readObj".equals(methodName)) {
			String wireFormat = (String)params[0];
			if ("XML".equals(wireFormat)) {
				return deserializeData(new XMLDeserialization());
			}
		}
		// Handle write operation
		if ("writeObj".equals(methodName)) {
			String wireFormat = (String)params[1];
			if ("XML".equals(wireFormat)) {
				serializeData((SerializableObject)params[0], new XMLSerialization());
				return null;
			}
		}
		return null;
	}

	public void setAndOpenCpointFile(String fileName) {
		this.cpointFile = fileName;
		this.fpForCpointFile = new FileProcessor();
		this.fpForCpointFile.setScanner(fileName);
	}

	public void closeCpointFile() {
		this.fpForCpointFile.closeScanner();
	}

	public void setAndOpenVerifyFile(String fileName) {
		this.verifyFile = fileName;
		this.fpForVerifyFile = new FileProcessor();
		this.fpForVerifyFile.setWriter(fileName);
	}

	public void closeVerifyFile() {
		this.fpForVerifyFile.closeWriter();
	}

	public List<SerializableObject> deserializeData(DeserStrategy dsStrategy) {
		return dsStrategy.processInput(this.fpForCpointFile);
	}

	public void serializeData(SerializableObject sObject, SerStrategy sStrategy) {
		sStrategy.processInput(sObject, this.fpForVerifyFile);
	}
}