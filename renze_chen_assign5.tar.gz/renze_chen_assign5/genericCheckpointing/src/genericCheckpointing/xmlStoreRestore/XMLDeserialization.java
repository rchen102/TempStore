package genericCheckpointing.xmlStoreRestore;

import java.util.List;
import java.util.ArrayList;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.SerializableObject;

public class XMLDeserialization implements DeserStrategy {
	
	@Deprecated
	public List<SerializableObject> processInput(FileProcessor fp) {
		List<SerializableObject> myRecord = new ArrayList<>();
		
		boolean isObjectCreate = false;
		Class<?> cls = null; 
		Object obj = null;
		while (fp.hasNext()) {
			String line = fp.readOneLine();
			if (line.contains("DPSerialization")) continue;

			if (line.contains("<complexType")) {
				String nameOfClass = MyStringExtract.extractClassName(line);
				try {
					cls = Class.forName(nameOfClass); 
					obj = cls.newInstance();
					isObjectCreate = true;
				} 
				catch (ClassNotFoundException ex) {
					System.err.println("Error: class '" + nameOfClass + "' not found.");
					ex.printStackTrace();
					System.exit(0);
				}
				catch (InstantiationException ex) {
					System.err.println("Error: class '" + nameOfClass + "' can not be instantiated.");
					ex.printStackTrace();
					System.exit(0);
				}
				catch (IllegalAccessException ex) {
					System.err.println("Error: default constructor of class '" + nameOfClass + "' can not be access.");
					ex.printStackTrace();
					System.exit(0);
				}
				continue;
			}

			if (line.contains("</complexType>")) {
				myRecord.add((SerializableObject)obj);
				cls = null;
				obj = null;
				isObjectCreate = false;
				continue;
			}

			if (line.contains("xsd")) {
				String value = MyStringExtract.extractValue(line);
				String fieldName = MyStringExtract.extractFieldName(line);
				String fieldType = MyStringExtract.extractFieldType(line);
				String setMethodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
				try {
					this.invokeSetMethod(obj, cls, value, fieldType, setMethodName);
					continue;
				}
				catch (NoSuchMethodException ex) {
					System.err.println("Error: method '" + setMethodName + "' not found.");
					ex.printStackTrace();
					System.exit(0);
				}
				catch (IllegalAccessException ex) {
					System.err.println("Error: method '" + setMethodName + "' can not be access.");
					ex.printStackTrace();
					System.exit(0);
				}
				catch (InvocationTargetException ex) {
					System.err.println("Error: exception occured when invoke method '" + setMethodName + "'.");
					ex.printStackTrace();
					System.exit(0);
				}
			}
		}
		return myRecord;
	}

	private void invokeSetMethod(Object obj, Class<?> cls, String value, String fieldType, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		if ("byte".equals(fieldType)) {
			this.setValueForByte(obj, cls, value, setMethodName);
		}
		else if ("short".equals(fieldType)) {
			this.setValueForShort(obj, cls, value, setMethodName);
		}
		else if ("int".equals(fieldType)) {
			this.setValueForInt(obj, cls, value, setMethodName);
		}
		else if ("long".equals(fieldType)) {
			this.setValueForLong(obj, cls, value, setMethodName);
		}
		else if ("float".equals(fieldType)) {
			this.setValueForFloat(obj, cls, value, setMethodName);
		}
		else if ("double".equals(fieldType)) {
			this.setValueForDouble(obj, cls, value, setMethodName);
		}
		else if ("boolean".equals(fieldType)) {
			this.setValueForBoolean(obj, cls, value, setMethodName);
		}
		else if ("char".equals(fieldType)) {
			this.setValueForChar(obj, cls, value, setMethodName);
		}
		else if ("string".equals(fieldType)) {
			this.setValueForString(obj, cls, value, setMethodName);
		}
	}

	public void setValueForByte(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, byte.class);
		setMethod.invoke(obj, Byte.parseByte(value));
	}

	public void setValueForShort(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, short.class);
		setMethod.invoke(obj, Short.parseShort(value));
	}

	public void setValueForInt(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, int.class);
		setMethod.invoke(obj, Integer.parseInt(value));
	}

	public void setValueForLong(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, long.class);
		setMethod.invoke(obj, Long.parseLong(value));
	}

	public void setValueForFloat(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, float.class);
		setMethod.invoke(obj, Float.parseFloat(value));
	}

	public void setValueForDouble(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, double.class);
		setMethod.invoke(obj, Double.parseDouble(value));
	}

	public void setValueForBoolean(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, boolean.class);
		setMethod.invoke(obj, Boolean.parseBoolean(value));
	}

	public void setValueForChar(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, char.class);
		setMethod.invoke(obj, value.charAt(0));
	}

	public void setValueForString(Object obj, Class<?> cls, String value, String setMethodName) 
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setMethod = cls.getMethod(setMethodName, String.class);
		setMethod.invoke(obj, value);
	}
}