package genericCheckpointing.xmlStoreRestore;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.util.FileProcessor;

public class XMLSerialization implements SerStrategy {
	public void processInput(SerializableObject obj, FileProcessor fp) {
		Class<?> cls = obj.getClass();
		Field[] fields = cls.getDeclaredFields();

		fp.writeOneLine("<DPSerialization>\n");
		fp.writeOneLine(this.serializeType(cls.getName()));
		for (Field field : fields) {
			String fieldName = field.getName();
			String fieldType = field.getType().getSimpleName().toLowerCase();

			String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
			String value = this.getValue(obj, cls, getMethodName);

			fp.writeOneLine(this.serializeField(fieldType, fieldName, value));
		}
		fp.writeOneLine(" </complexType>\n");
		fp.writeOneLine("</DPSerialization>\n");
	}

	private String getValue(SerializableObject obj, Class<?> cls, String getMethodName) {
		String value = "";
		try {
			Method getMethod = cls.getMethod(getMethodName, new Class[] {});
			value = String.valueOf(getMethod.invoke(obj, new Object[] {}));
		}
		catch (NoSuchMethodException ex) {
			System.err.println("Error: method '" + getMethodName + "' not found.");
			ex.printStackTrace();
			System.exit(0);
		}
		catch (IllegalAccessException ex) {
			System.err.println("Error: method '" + getMethodName + "' can not be access.");
			ex.printStackTrace();
			System.exit(0);
		}
		catch (InvocationTargetException ex) {
			System.err.println("Error: exception occured when invoke method '" + getMethodName + "'.");
			ex.printStackTrace();
			System.exit(0);
		}
		return value;
	}

	private String serializeType(String clsName) {
		return " <complexType xsi:type=\"" + clsName + "\">\n";
	}

	private String serializeField(String fieldType, String fieldName, String value) {
		return "  <" + fieldName + " xsi:type=\"xsd:" + fieldType + "\">" + value + "</" + fieldName + ">\n";
	}
}